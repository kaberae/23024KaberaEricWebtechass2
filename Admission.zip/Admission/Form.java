
package form;


import javax.mail.*;
import javax.mail.internet.*;
import java.util.Properties;

public class Form {

    public static void main(String[] args) {
       
        String to = "candidate@example.com";

        
        String from = "your-email@example.com";

       
        String password = "your-password";

        
        Properties properties = new Properties();
        properties.put("mail.smtp.auth", "true");
        properties.put("mail.smtp.starttls.enable", "true");
        properties.put("mail.smtp.host", "smtp.example.com"); // Replace with your SMTP server
        properties.put("mail.smtp.port", "587"); // Replace with your SMTP port

       
        Session session = Session.getInstance(properties, new Authenticator() {
         
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(from, password);
            }
        });

        try {
            
            Message message = new MimeMessage(session);

            
            message.setFrom(new InternetAddress(from));

           
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));

            
            message.setSubject("Admission Form Submission Confirmation");

           
            message.setText("Dear Candidate,\n\nThank you for submitting your admission form. Your application has been received.");

         
            Transport.send(message);

            System.out.println("Confirmation email sent successfully!");

        } catch (MessagingException e) {
            e.printStackTrace();
            System.err.println("Error sending confirmation email: " + e.getMessage());
        }
    }
}

